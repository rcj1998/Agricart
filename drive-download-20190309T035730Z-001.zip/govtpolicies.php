<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<?php include('header.php'); ?>
<html>
<title>Government Subsidies</title>
<head>
<style>
body{
	background-color:#f1f3f6;
}
</style></head>
<body>
<h2 style="margin-top:30px;"><center>GOVERNMENT POLICIES</H2></CENTER>
<br>
<div class="card" style="width: 18rem;margin-left:25%;width:700px;">
  <center>
  <div class="card-body">
    <div class="alert alert-primary" role="alert">
 <a href="http://pib.nic.in/newsite/PrintRelease.aspx?relid=179046" class="alert-link">Green Revolution-Krishonnati Yojana</a>
</div>
<div class="alert alert-secondary" role="alert">
 <a href="https://nbm.nic.in/" class="alert-link"> National Bamboo Mission  </a>
</div>
<div class="alert alert-success" role="alert">
 <a href="https://soilhealth.dac.gov.in/" class="alert-link">Soil Health Card Scheme</a>
</div>
<div class="alert alert-danger" role="alert">
 <a href="http://agricoop.nic.in/sites/default/files/National%20Mission%20For%20Sustainable%20Agriculture-DRAFT-Sept-2010.pdf" class="alert-link"> National Mission for Sustainable Agriculture(NMSA)</a>
</div>
<div class="alert alert-warning" role="alert">
  <a href="https://pmksy.gov.in/" class="alert-link">  Pradhan Mantri Krishi Sinchai Yojana(PMKSY)</a>
</div>
</center>
  </div>
  
</div>
<h2 style="margin-top:30px;"><center>SUBSIDIES</H2></CENTER>
<br>
<div class="card" style="width: 18rem;margin-left:25%;width:700px;">
  
  <div class="card-body"><center>
    <div class="alert alert-primary" role="alert">
  <a href="https://pmfby.gov.in/" class="alert-link">PMFBY </a>
</div>
<div class="alert alert-secondary" role="alert">
   <a href="http://pib.nic.in/newsite/PrintRelease.aspx?relid=65798" class="alert-link">National Agricultural Insurance Scheme (MNAIS)</a>
</div>
<div class="alert alert-success" role="alert">
  <a href="http://www.aicofindia.com/AICEng/General_Documents/Product_Profiles/Coconut_Palm.pdf" class="alert-link">Coconut Palm Insurance Scheme (CPIS)</a>
</div>
<div class="alert alert-danger" role="alert">
   <a href="http://pib.nic.in/newsite/PrintRelease.aspx?relid=179046" class="alert-link"> Integrated Scheme on Agriculture Cooperation (ISAC)</a>
</div>
<div class="alert alert-warning" role="alert">
 <a href="https://rkvy.nic.in/" class="alert-link">Rashtriya Krishi Vikas Yojana (RKVY)</a>
</div>
</center>
  </div>
  
</div>

</body>
</html>