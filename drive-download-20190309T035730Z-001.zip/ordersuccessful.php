<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<html>
<title>Order Succesful</title>
<head>
<script src="jquery-3.3.1.min.js"></script>
<style>
body {
			padding:0;
			margin:0;
			background-color:#f1f3f6;
		}
		
</style>
</head>
<body>

<span class="d-block p-3 bg-primary text-white" style="margin-top:0px;height:100px;"><center><b><div style=""><h1>Your Order Is Succesfully Placed</h1></b></center></span>
<script>$(<img src="box.png").addClass('animated bounceOutLeft');</script>
<div ><center><img src="images/cartphoto.png" style="height:30%;margin-top:150px"></center></div>

</body>
</html>