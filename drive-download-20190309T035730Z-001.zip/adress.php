<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<html>
<title>
Address Page
</title>
<head>
<style>

</style>
</head>
<body style="background-color:#f1f3f6">
<div class="topbar" align="center" style="margin-top:50px;color:"success" ><font color="secondary">
<h2>SHIPPING  ADDRESS</h2>	
</div></font>
<div class="row">
<div class="card text-white bg-info mb-6 shadow p-3 mb-6  rounded" style="max-width: 18rem;margin-left:245px;margin-top:100px;height:30%;border:2px black solid">
  
  <div class="card-body">
    <h5 class="card-title">Address :</h5>
    <p class="card-text">M-II 191 Fateh Villa Kitiyani Colony Mandsaur</p>
</div>
</div>
<div class="card text-white bg-info mb-5" style="max-width: 18rem;margin-left:320px;margin-top:100px;height:30%;border:2px black solid">
  
  <div class="card-body">
    <h5 class="card-title">Address :</h5>
    <p class="card-text">M-II 191 Fateh Villa Kitiyani Colony Mandsaur</p>
</div>
</div >
</div>
<div>
	  <input  type="radio" name="ship_add" value="ship_add_diff" style="margin-left:245px;">
      <input type="radio" name="ship_add" value="ship_add_same" style="margin-left:600px;">
</div>
<div align="center">
  <button type="button" class="btn btn-success" align="center" style="margin-top:80px;align:center;" >Place Your Order</button>
</div>


</body>
</html>